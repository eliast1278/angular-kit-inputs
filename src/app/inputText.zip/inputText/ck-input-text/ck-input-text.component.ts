import {Component, Input} from "@angular/core";

@Component({
  selector: "ck-input-text",
  templateUrl: 'ck-input-text.component.html',
  styleUrls: ['ck-input-text.component.scss'],

})
export class CkInputTextComponent {
  @Input() label: string = "";
  @Input() labelPos: "in" | "out" = "out";
  @Input() inlineIcon: boolean = false;
  @Input() state: "regular" | "success" | "error" | "warning" = "regular";
  @Input() valueAlignment: "right" | "left" = "right";
  @Input() placeholder: string | null = null;
  @Input() disabled: boolean = false;
}
