import {Input, NgModule} from "@angular/core";
import {CkInputTextComponent} from "./ck-input-text/ck-input-text.component";

@NgModule({
  declarations: [CkInputTextComponent],
  imports: [],
  exports: [CkInputTextComponent]
})
export class CkInputTextModule {
}
